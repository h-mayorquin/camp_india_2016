Running the Simulation:
	Enter the directory containing the files and rum the following command
	$ mcell main.mdl
	
******************************

Load the Geometry in Blender:
	File -> Impoer -> MCell MDL (.mdl)
	Then browse and select the geometry.mdl file and Enter.
	
******************************

Visualising Simulation Data in Blender:
	In the left panel, find "CellBlender - Visualize Simulation Results" and expand it.
	Select "Manually Select Viz Directory".
	Click on "Read Viz Data"
	Go to the viz folder (by default its in ./data/s_00001/viz) and click on "Read Viz Data"
	On the bottom panel, click on the play button (large triangular button) to run the visualization.
	ENJOY!
