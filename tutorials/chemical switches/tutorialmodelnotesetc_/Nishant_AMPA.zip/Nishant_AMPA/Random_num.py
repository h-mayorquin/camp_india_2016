import random

def main():
	count=1
	f = open('ampar_disk_130.mdl', 'w')

	preText = '''ampar_disk RELEASE_SITE {
  SHAPE = LIST
  MOLECULE_POSITIONS {\n'''
	f.write(preText)
	while (count <= 130):
		f.write("  AMPA' [")	
		x = random.uniform(-0.042, 0.042)
		y = random.uniform(-0.042, 0.042)
		f.write(str(x))
		f.write(", ")
		f.write(str(y))
		f.write(", 0]\n")
		count = count+1
	f.write('''  }
	SITE_RADIUS = 0.042
}''')

if __name__ == "__main__": main()
